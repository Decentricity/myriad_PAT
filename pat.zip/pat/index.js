const axios = require('axios')

const jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY0OTNjZjI0OGM0MjFkMDAwMWNkYjdlMiIsIm5hbWUiOiJOaXgiLCJ1c2VybmFtZSI6Im5peGZydCIsImNyZWF0ZWRBdCI6IjIwMjMtMDYtMjJUMDQ6MzQ6MjQuNTY1WiIsInBlcm1pc3Npb25zIjpbInVzZXIiXSwiaWF0IjoxNjk4MTI2OTEwfQ.YZVbSl_02nhFb0rlHHXLuOX4gWpsdTxMPYWPSTeYWu8"

const url = "https://api.testnet.myriad.social/"
const headers = {Authorization: `Bearer ${jwt}`}

const sleep = (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}

const login = async (token) => {
    const endpoint = url+ "authentication/login/pat"
    const requestBody = {
        token: token
    }
    const response = await axios.post(endpoint,requestBody)
    return response

}

const generate = async () => {
    const endpoint = url + "user/personal-admin-access-tokens"
    const response = await axios.get(endpoint,{
        headers: {
          'Authorization': `Bearer ${jwt}`
        }
      })
    return response.data
}

const revoke = async (token) => {
    const endpoint = url + "user/personal-access-tokens/" + String(token)
    const response = axios.delete(endpoint,{
        headers: {
          'Authorization': `Bearer ${jwt}`
        }
      })
      return response.data

}

const main = async () => {
    const token = await generate().then(resp => {return resp.id})
    console.log(`Token is ${token}`)
    console.log("Logging in with token ")
    await login(String(token)).then(resp => {
        console.log(resp.data)
        console.log("Login successful")
    }).catch(e => {
        console.log("logging in failed. this is unexpected.")
        console.error(e)
    })
    await revoke(token).then(resp => {
        console.log("revoking successful")
    }).catch(e => {
        console.error(e)
    })
    await sleep(3000) 
    // sleep is necessary because logging in instantly after revoking still works
    await login(String(token)).then(resp => {
        console.log(resp.data)
    }).catch(e => {
        console.log("Logging in failed. This is expected behaviour")
        console.error(e)
    })

}

main().catch(e => console.error(e))
